Doing site about my cat, there is :
Facts about my cat.
How he looks like.
what does he like to do.
